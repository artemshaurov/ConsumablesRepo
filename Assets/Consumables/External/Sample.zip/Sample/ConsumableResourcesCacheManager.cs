using System;
using Common.SimpleDataPersistence.Runtime;

namespace Common.Consumables.External
{
    public class ConsumableResourcesCacheManager : IConsumableResourcesCacheManager
    {
        private readonly IDataManager m_DataManager;
        private readonly IResourceNameToDataKeyConverter m_KeyConverter;

        public ConsumableResourcesCacheManager(
            IDataManager dataManager, 
            IResourceNameToDataKeyConverter keyConverter)
        {
            m_DataManager = dataManager;
            m_KeyConverter = keyConverter;
        }
        
        public ConsumableResourceData Load(
            string resourceName,
            Func<ConsumableResourceData> createDefault)
        {
            var result = m_KeyConverter.GetDataKey(resourceName);
            if (!result.IsExist)
            {
                m_KeyConverter.Register(resourceName, resourceName);
            }

            return m_DataManager.GetData(result.Object, createDefault);
        }
    }
}