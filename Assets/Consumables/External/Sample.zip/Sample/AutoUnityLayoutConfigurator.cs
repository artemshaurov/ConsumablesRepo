using Common.Consumables.View;
using UnityEngine;
using UnityEngine.UI;

namespace Common.Consumables.External
{
    public class AutoUnityLayoutConfigurator : ILayoutConfigurator
    {
        public void UpdateLayout(RectTransform root)
        {
            LayoutRebuilder.MarkLayoutForRebuild(root);
        }
    }
}