using System.Linq;
using Common.Consumables.View;
using Common.SimpleDataPersistence.Runtime;
using Core.SceneManagers.StartScene.Phases;
using MasterFSM;
using UnityEngine;
using Winter.Attributes;

namespace Common.Consumables.External
{
    [MonoController]
    [Stage(nameof(StartSceneInitPhase))]
    public class ConsumableResourcesWizard : MonoBehaviour, IControlEntity
    {
        [Inject] private IDataManager m_DataManager;
        [Inject] private IConsumableResourcesController m_ConsumableResourcesController;
        [Inject] private ConsumableResourceModelsRegistry m_ConsumableResourceModelsRegistry;
        [Inject] private IConsumableResourceIconController m_ConsumableResourceIconController;
        private Result<ConsumableResourcesInfo> m_ResourcesInfoResult;
        private ConsumableResourcesInfoLoader m_ResInfoInfoLoader;

        public OperationStatus PreInit()
        {
            m_ResInfoInfoLoader = new ConsumableResourcesInfoLoader();
            m_ResourcesInfoResult = m_ResInfoInfoLoader.Load();

            if (!m_ResourcesInfoResult.IsExist)
            {
                return new OperationStatus(Operation.Success, Operation.Async);
            }

            foreach (var resourceInfo in m_ResourcesInfoResult.Object.Resources)
            {
                m_ConsumableResourceModelsRegistry.Register(resourceInfo);
            }
                
            m_ConsumableResourceIconController.PreloadAll(
                m_ResourcesInfoResult
                    .Object
                    .Resources
                    .SelectMany(o => o.IconAddress.Values)
                    .ToArray());


            return new OperationStatus(Operation.Success, Operation.Async);
        }

        public OperationStatus Initing()
        {
            ConfigureLogic();
            return new OperationStatus(Operation.Success, Operation.Async);
        }

        private void ConfigureLogic()
        {
            var keyConverter = new ResourceNameToDataKeyConverter();
            if (m_ResourcesInfoResult.IsExist)
            {
                foreach (var resourceInfo in m_ResourcesInfoResult.Object.Resources)
                {
                    keyConverter.Register(resourceInfo.ResourceName, resourceInfo.DataKey);
                }
            }

            var cacheManager = new ConsumableResourcesCacheManager(
                m_DataManager,
                keyConverter);

            var registrar = new ConsumableResourceEarnerRegistrar(
                m_ResourcesInfoResult,
                cacheManager,
                m_ConsumableResourcesController);

            registrar.RegisterAll();
        }

        public OperationStatus PostInit()
        {
            return new OperationStatus(Operation.Success, Operation.Async);
        }
    }
}