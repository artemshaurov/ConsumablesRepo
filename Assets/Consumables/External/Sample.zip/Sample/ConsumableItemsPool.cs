using Common.Consumables.View;
using Common.SmartPool;

namespace Common.Consumables.External
{
    public class ConsumableItemsPool : IConsumableItemsPool
    {
        private readonly SmartPool<IConsumableResourceView> m_Pool;

        public ConsumableItemsPool(IConsumableResourceView sampleView)
        {
            m_Pool = new SmartPool<IConsumableResourceView>(sampleView);
        }

        public IConsumableResourceView Pop()
        {
            return m_Pool.Pop();
        }

        public void Return(IConsumableResourceView view)
        {
            m_Pool?.ReturnItemInPull(view);
        }

        public void ReturnAll()
        {
            m_Pool?.ReturnAllItems();
        }

        public void Clear()
        {
            ReturnAll();
            m_Pool?.DestroyAll();
        }
    }
}