using System.Collections.Generic;
using Common.AddressablesManager;
using Common.Consumables.View;
using UnityEngine;
using Winter.Attributes;

namespace Common.Consumables.External
{
    public class CardGameIconLoader : IIconLoader
    {
        [Inject]
        private AddressableService m_AddressableService;

        private Dictionary<string, AddressableInfo<Sprite>> m_AddressableInfos
            = new Dictionary<string, AddressableInfo<Sprite>>();

        private readonly Dictionary<string, IconLoadingWrapper> m_CacheMap
            = new Dictionary<string, IconLoadingWrapper>();

        public IconLoadingWrapper Load(string address)
        {
            if (m_CacheMap.ContainsKey(address))
            {
                return m_CacheMap[address];
            }
            
            var addressableInfo 
                = m_AddressableService.GetOrLoadAddressableAsset<Sprite>(address);
            
            var loadingWrapper = new IconLoadingWrapper();
            m_CacheMap.Add(address, loadingWrapper);
            
            if (addressableInfo.IsLoaded)
            {
                loadingWrapper.IsCompleted = true;
                loadingWrapper.IsSucceed = true;
                loadingWrapper.Result = new SpriteResourceIcon(addressableInfo.Result);
            }
            else
            {
                addressableInfo.OnLoaded += sprite =>
                { 
                    loadingWrapper.IsCompleted = true;
                    loadingWrapper.IsSucceed = true;
                    loadingWrapper.Result = new SpriteResourceIcon(sprite);
                };
            }

            return loadingWrapper;
        }
    }
}