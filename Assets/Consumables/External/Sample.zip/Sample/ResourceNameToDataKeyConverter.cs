using System.Collections.Generic;

namespace Common.Consumables.External
{
    public class ResourceNameToDataKeyConverter : IResourceNameToDataKeyConverter
    {
        private readonly Dictionary<string, string> m_ResourceNameToDataKeyMap 
            = new Dictionary<string, string>();
        
        public void Register(string resourceName, string dataKey)
        {
            m_ResourceNameToDataKeyMap[resourceName] = dataKey;
        }
        
        public Result<string> GetDataKey(string resourceName)
        {
            return  m_ResourceNameToDataKeyMap.TryGetValue(resourceName, out var dataKey)
                ? Result<string>.Success(dataKey)
                : Result<string>.Fail($"Resource '{resourceName}' is" +
                                      $" not registered in ResourceNameToDataKeyController");
        }
    }
}