using Common.Consumables.View;

namespace Common.Consumables.External
{
    public class CardGameConsumableItemsPoolFactory : IConsumableItemsPoolFactory
    {
        public IConsumableItemsPool Create(IConsumableResourceView view)
        {
            return new ConsumableItemsPool(view);
        }
    }
}