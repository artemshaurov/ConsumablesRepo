using Common.Consumables.View;
using UnityEngine;

namespace Common.Consumables.External
{
    public class DefaultConsumableRewardsPackView : MonoBehaviour, IConsumableItemsPackView
    {
        [SerializeField] private RectTransform m_LayoutBody;
        private ILayoutConfigurator m_LayoutConfigurator = new AutoUnityLayoutConfigurator();

        public void SetLayoutConfigurator(ILayoutConfigurator layoutConfigurator)
        {
            m_LayoutConfigurator = layoutConfigurator;
        }
        
        public void AddItem(IConsumableResourceView view)
        {
            if (view is not MonoBehaviour monoBehaviour)
            {
                return;
            }

            var viewTransform = monoBehaviour.transform;
            viewTransform.SetParent(m_LayoutBody);
            viewTransform.localScale = Vector3.one;
        }

        public void UpdateLayout()
        {
            m_LayoutConfigurator.UpdateLayout(m_LayoutBody);
        }
    }
}