namespace Common.Consumables.External
{
    public interface IResourceNameToDataKeyConverter
    {
        void Register(string resourceName, string dataKey);
        Result<string> GetDataKey(string resourceName);
    }
}